function f1(){
	// document.getElementByid('inp1'). value
	alert(document.getElementById('inp1').value*document.getElementById('inp1').value)
}